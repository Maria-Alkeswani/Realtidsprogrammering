#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<ctype.h>
#include<math.h>

struct Node
{
    int n;
    char c;
    struct Node *next;
};

//-----------------------------------------------------------
// Task3 : 4.1

void input_list(struct Node **p,int value,char c);
void print_list(struct Node *p);
void create_values_to_list(struct Node **p,int count,char c);
//--------------------------------------------------------------
//Task3 : 4.2
char* two_d_alloc(int r,int c,int s);
void two_d_store(char*d,int i,int j,int s,struct Node *n11);
struct Node two_d_fetch(char*d,int i,int j,int s);
void two_d_dealloc(char*d,int r,int c,int s);
//------------------------------------------------------------
//Task3 : 4.3
void dump_memory(char* str,int len);

int col;

int main()
{   
    
    // --> 4.1 creating the link list
    printf("--> 4.1 creating the link list\n");
    struct Node *ptr=NULL;
    create_values_to_list(&ptr,10,'A');

    print_list(ptr);    
    

    printf("sizeof: %d \n",sizeof(*ptr));

    //=================================================
    // --> 4.2 Storing the list
    printf("\n--> 4.2 Storing the list\n");

    char *arr=two_d_alloc(10,1,sizeof(struct Node));

    int i;
    for(i=0;i<10;i++)
    two_d_store(arr,i,0,sizeof(struct Node),ptr);    //column=1 --> index=0

    for(i=0;i<10;i++)
    printf("int: %d char: %c\n",two_d_fetch(arr,i,0,sizeof(struct Node)).n,two_d_fetch(arr,i,0,sizeof(struct Node)).c);
    
    //=================================================
    // --> 4.3 Analyzing
    printf("\n--> 4.3 Analyzing\n");
    dump_memory(arr,10*1*sizeof(struct Node));

    two_d_dealloc(arr,10,1,sizeof(struct Node));

	return 0;
}
//----------------------------------------------------------------------

// Task3 : 4.1

void input_list(struct Node **p,int value,char c)
{
    if(*p==NULL)
    {
        *p=(struct Node*) malloc(sizeof(struct Node));
        (*p)->n=value;
        (*p)->c=c;
        (*p)->next=NULL;
    }
    else
    input_list(&((*p)->next),value,c);
}

void print_list(struct Node *p)
{
    struct Node *i;
    for(i=p;i!=NULL;i=i->next)
    printf("number: %d , char: %c \n",i->n,i->c);
}

void create_values_to_list(struct Node **p,int count,char c)
{
    int i;
    for(i=0;i<count;i++)
    input_list(p,i,c);
}
//-----------------------------------------------------------
// Task3 : 4.2
char* two_d_alloc(int r,int c,int s)  //s=sizeof(int)+sizeof(char)
{
    col=c;
    char *d=(char*)malloc(r*c*s);
}
void two_d_store(char*d,int i,int j,int s,struct Node *n11)
{
    int pos,j1,n;
    

    for(j1=0;j1<i;j1++)
    n11=n11->next;
    
    pos=((i*col)+j)*s;
    memcpy(d+pos,(char*)n11,s);
    
}
struct Node two_d_fetch(char*d,int i,int j,int s)
{
    int pos,n,k;
    struct Node *aux=(struct Node *)malloc(s);
    pos=((i*col)+j)*s;

    memcpy((char*)aux,(d+pos),s);

     return *aux;
}
void two_d_dealloc(char*d,int r,int c,int s)
{
    int i;
    //for(i=0;i<r*c*s;i++)    //for delete d
    //free(d+i);
    memset(d, 0, r*c*s);
}
//-----------------------------------------------------
//Task3 : 4.3
void dump_memory(char* str,int len)
{
    int i,i1,j;
    for(i=0;i<len;i++)
    {

        for(j=0;j<4;j++)
        {
            if(j==0) printf("0x%x ",str+i);
            for(i1=0;i1<4;i1++)
            {
                printf("%.2hhx",*(str+i+i1));
            }
            i+=4;
            printf(" ");
        }
        i=i-16;

        for(j=0;j<4;j++)  //4 word
        {
            for(i1=0;i1<4;i1++)     //1 word = 4 char = 4 bytes
            {
                if((isalpha(*(str+i+i1)) || isdigit(*(str+i+i1))) && i1<len)
                printf("%c",*(str+i+i1)); 
                else if (!(isalpha(*(str+i+i1)) && isdigit(*(str+i+i1))) || i1>=len)
                printf(".");
            }
            i+=4;
            printf(" ");
        }
        i=i-1;
        printf("\n");

    }
}
