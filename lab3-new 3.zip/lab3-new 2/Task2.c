#include<stdio.h>
#include<string.h>
#include<ctype.h>

void dump_memory(char* str,int len);
int main()
{
    char *str;
    str="Welcome to C++aaaa";
    
    dump_memory(str,strlen(str));
    
    printf("\n-------------------------------------\n");



    return 0;
}




void dump_memory(char* str,int len)
{
    int i,i1,j;
    for(i=0;i<len;i++)
    {

        for(j=0;j<4;j++)
        {
            if(j==0) printf("0x%x ",str+i);
            for(i1=0;i1<4;i1++)
            {
                printf("%.2x",*(str+i+i1));
            }
            i+=4;
            printf(" ");
        }
        i=i-16;

        for(j=0;j<4;j++)  //4 word
        {
            for(i1=0;i1<4;i1++)     //1 word = 4 char = 4 bytes
            {
                if((isalpha(*(str+i+i1)) || isdigit(*(str+i+i1))) && i1<len)
                printf("%c",*(str+i+i1)); 
                else if (!(isalpha(*(str+i+i1)) && isdigit(*(str+i+i1))) || i1>=len)
                printf(".");
            }
            i+=4;
            printf(" ");
        }
        i=i-1;
        printf("\n");

    }
}









