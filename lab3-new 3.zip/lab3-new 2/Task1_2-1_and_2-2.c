#include <stdio.h>
#include <stdlib.h>
#include <math.h>

char* two_d_alloc(int r,int c,int s);
void two_d_store(char*d,int i,int j,int s,int n);
int two_d_fetch(char*d,int i,int j,int s);
void two_d_dealloc(char*d,int r,int c,int s);

void read_row_major(char*d,int r,int c);
void print_array(char*d,int r,int c);
void read_column_major(char*d,int r,int c);

int col;

int main()
{
    char *d=two_d_alloc(20,50,sizeof(int));

    int r,c;
    r=3;
    c=4;

    printf(">> Row-major mode\n");
    read_row_major(d,r,c);
    print_array(d,r,c);

    printf("\n>> Column-major mode\n");
    read_column_major(d,r,c);
    print_array(d,r,c);
    
    two_d_dealloc(d,r,c,sizeof(int));
    

	return 0;
}
//-------------------------------------------------------------
void read_row_major(char*d,int r,int c)
{
    int i,j,s=1;
    col=c;
    for(i=0;i<r;i++)
    for(j=0;j<c;j++)
    two_d_store(d,i,j,sizeof(int),s++);
    
}
void print_array(char*d,int r,int c)
{
    int i,j;
    for(i=0;i<r;i++)
    {
    for(j=0;j<c;j++)
    printf("%d ", two_d_fetch(d,i,j,sizeof(int)));
    printf("\n");
    }
}

void read_column_major(char*d,int r,int c)
{
    int i,j,s=1;
    col=c;
    for(j=0;j<c;j++)
    for(i=0;i<r;i++)
    two_d_store(d,i,j,sizeof(int),s++);
}
//-------------------------------------------------------------
char* two_d_alloc(int r,int c,int s)
{
    char *d;
    d = (char*)malloc(r*c*s);
}

void two_d_store(char*d,int i,int j,int s,int n)
{
    int pos;
    pos=((i*col)+j)*s;         //c=column=4
    for(i=0;i<s;i++)
    *(d+pos+i)=(n >> (8*i)) & 0xFF;
    return;
}

int two_d_fetch(char*d,int i,int j,int s)
{
    int pos,y;

    pos=((i*col)+j)*s;
    
    y=0;
    for(i=0;i<s;i++)
    y+=*(d+pos+i)*pow(256.0,i);
    return y;
}

void two_d_dealloc(char*d,int r,int c,int s)
{
    int i;
    for(i=0;i<r*c*s;i++)    //for delete d
    free(d+i);  
}