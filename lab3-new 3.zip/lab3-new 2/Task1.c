#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{

	int *d,r,c,i,j,y,pos1,pos2,n;
	r=20; //row
    c=50; //column
    d=(int*)malloc(r*c*sizeof(int));
    
    
    i=10; j=15;
    n=4;
    pos1=((i*c)+j)*sizeof(int);
    *(d+pos1+0)=(n >> 0) & 0xFF;
    *(d+pos1+1)=(n >> 8) & 0xFF;
    *(d+pos1+2)=(n >> 16) & 0xFF;
    *(d+pos1+3)=(n >> 24) & 0xFF;
    
    int y1=0;
    for(i=0;i<4;i++)
    y1+=*(d+pos1+i)*pow(256.0,i);
    

    
    i=12; j=42;
    n=3;
    pos2=((i*c)+j)*sizeof(int);
    *(d+pos2+0)=(n >> 0) & 0xFF;
    *(d+pos2+1)=(n >> 8) & 0xFF;
    *(d+pos2+2)=(n >> 16) & 0xFF;
    *(d+pos2+3)=(n >> 24) & 0xFF;
    
    int y2=0;
    for(i=0;i<4;i++)
    y2+=*(d+pos2+i)*pow(256.0,i);


    y=y1+y2;         //y=d[12,42]+d[10,15];

    printf("%d",y);

    //for delete d
    free(d);        
    
	return 0;
}
 